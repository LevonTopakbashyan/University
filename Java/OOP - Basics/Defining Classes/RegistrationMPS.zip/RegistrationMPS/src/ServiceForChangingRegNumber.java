public interface ServiceForChangingRegNumber {

     int receivingRequests(RegistrationRequest request);

}
